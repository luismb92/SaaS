﻿function login() {
    const loader = document.getElementById("loader");
    loader.style.display = "block";
    setTimeout(() => {
        window.location.href = "/Home/Dashboard";
    }, 1000);
}