﻿function toggleMenu() {
    const sidebar = document.getElementById("sidebar");
    const main = document.getElementById("main");
    if (!sidebar || !main) {
        console.error("No encontró sidebar o main");
        return;
    }
    // 📱 MOBILE
    if (window.innerWidth <= 768) {
        sidebar.classList.toggle("active");
    }
    // 💻 DESKTOP
    else {
        sidebar.classList.toggle("collapsed");
        main.classList.toggle("expanded");
    }
}