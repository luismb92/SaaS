﻿let celdaActual = null;
function abrirModal(td) {
    celdaActual = td;
    const modal = new bootstrap.Modal(document.getElementById('modalHorario'));
    modal.show();
}
