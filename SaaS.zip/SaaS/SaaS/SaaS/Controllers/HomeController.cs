using Microsoft.AspNetCore.Mvc;
using SaaS.Models;
using System.Diagnostics;

namespace SaaS.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Login()
        { 
            return View();
        }
        public IActionResult Dashboard()
        { 
            return View();
        }
        public IActionResult Alumnos()
        { 
            return View();
        }
        public IActionResult ExpedienteAlumnos()
        { 
            return View();
        }
        public IActionResult Profesores()
        { 
            return View();
        }
        public IActionResult Grupos()
        { 
            return View();
        }
        public IActionResult Horarios()
        { 
            return View();
        }
        public IActionResult Calificaciones() 
        {
            return View();
        }
        public IActionResult Asistencia() 
        {
            return View();
        }
        public IActionResult Psicologia() 
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
